import os
import base64
import cv2
import numpy as np
from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
import tensorflow as tf
from datetime import datetime
import serial
import time
import threading

# ========== CONFIGURACIÓN DE FLASK ==========
app = Flask(__name__)

# Auto-recarga de plantillas (para no reiniciar cada vez que editás index.html)
app.config['TEMPLATES_AUTO_RELOAD'] = True
app.config['SEND_FILE_MAX_AGE_DEFAULT'] = 0
app.config['TEMPLATES_AUTO_RELOAD'] = True

CORS(app)

# ========== CONFIGURACIÓN GENERAL ==========
UMBRAL_COMPOSTABLE = 0.75
MODEL_PATH = "modelo_compostable.tflite"
PUERTO_ARDUINO = 'COM3'   # <-- CAMBIA si es necesario
VELOCIDAD_SERIAL = 9600
PORCENTAJE_RECORTE = 0.6

# ========== CARGA DEL MODELO ==========
print("Cargando modelo de IA...")
interpreter = tf.lite.Interpreter(model_path=MODEL_PATH)
interpreter.allocate_tensors()
input_details = interpreter.get_input_details()
output_details = interpreter.get_output_details()
print("Modelo cargado correctamente.")

# ========== VARIABLES GLOBALES ==========
historial = []
ultimo_resultado = {'compostable': False, 'confianza': 0.0, 'timestamp': None}
trigger_captura = False
ser = None
estado_actual = {'cara': 'neutral', 'frase': '', 'timestamp': None}

# ========== FUNCIONES AUXILIARES ==========
def recortar_centro(img, porcentaje=0.6):
    h, w = img.shape[:2]
    nuevo_h = int(h * porcentaje)
    nuevo_w = int(w * porcentaje)
    y_inicio = (h - nuevo_h) // 2
    x_inicio = (w - nuevo_w) // 2
    return img[y_inicio:y_inicio + nuevo_h, x_inicio:x_inicio + nuevo_w]

def clasificar_imagen_bytes(imagen_bytes):
    np_arr = np.frombuffer(imagen_bytes, np.uint8)
    img = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
    if img is None:
        raise ValueError("No se pudo decodificar la imagen")

    img = recortar_centro(img, PORCENTAJE_RECORTE)

    input_shape = input_details[0]['shape']
    height, width = input_shape[1], input_shape[2]
    if img.shape[0] != height or img.shape[1] != width:
        img = cv2.resize(img, (width, height))

    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    img = img.astype(np.float32)
    img = np.expand_dims(img, axis=0)

    interpreter.set_tensor(input_details[0]['index'], img)
    interpreter.invoke()
    resultado = interpreter.get_tensor(output_details[0]['index'])[0][0]

    es_compostable = bool(resultado < UMBRAL_COMPOSTABLE)
    confianza = (1 - resultado) if es_compostable else resultado
    return es_compostable, float(confianza), float(resultado)

# ========== HILO SERIAL ==========
def leer_serial():
    global trigger_captura, ser
    while True:
        try:
            if ser and ser.is_open and ser.in_waiting > 0:
                linea = ser.readline().decode('utf-8', errors='ignore').strip()
                if linea:
                    print(f"Arduino: {linea}")
                    if 'D' in linea:
                        print("Comando 'D' recibido -> activar captura")
                        trigger_captura = True
        except Exception as e:
            print(f"Error serial: {e}")
        time.sleep(0.1)

# ========== CONEXIÓN ARDUINO ==========
try:
    ser = serial.Serial(PUERTO_ARDUINO, VELOCIDAD_SERIAL, timeout=1)
    time.sleep(2)
    print(f"Arduino conectado en {PUERTO_ARDUINO}")
    hilo = threading.Thread(target=leer_serial, daemon=True)
    hilo.start()
    print("Hilo serial iniciado")
except Exception as e:
    print(f"Arduino no conectado: {e}")
    ser = None

# ========== RUTAS ==========
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/admin')
def admin():
    return render_template('admin.html')

@app.route('/check_trigger', methods=['GET'])
def check_trigger():
    global trigger_captura
    if trigger_captura:
        trigger_captura = False
        return jsonify({'trigger': True})
    return jsonify({'trigger': False})

@app.route('/clasificar', methods=['POST'])
def clasificar():
    global ultimo_resultado, estado_actual
    try:
        data = request.get_json()
        imagen_base64 = data.get('imagen')
        if not imagen_base64:
            return jsonify({'error': 'No se recibio imagen'}), 400
        if ',' in imagen_base64:
            imagen_base64 = imagen_base64.split(',')[1]
        imagen_bytes = base64.b64decode(imagen_base64)
        es_compostable, confianza, raw = clasificar_imagen_bytes(imagen_bytes)

        registro = {
            'timestamp': datetime.now().isoformat(),
            'compostable': es_compostable,
            'confianza': round(confianza, 4),
            'raw': round(raw, 4)
        }
        historial.append(registro)

        ultimo_resultado['compostable'] = es_compostable
        ultimo_resultado['confianza'] = confianza
        ultimo_resultado['timestamp'] = registro['timestamp']

        if es_compostable and confianza >= 0.70:
            estado_actual = {'cara': 'happy', 'frase': 'compostable', 'timestamp': registro['timestamp']}
            if ser and ser.is_open:
                ser.write(b'1')
                print("Comando '1' -> abrir")
        elif not es_compostable and confianza >= 0.70:
            estado_actual = {'cara': 'sad', 'frase': 'no_compostable', 'timestamp': registro['timestamp']}
            if ser and ser.is_open:
                ser.write(b'0')
                print("Comando '0' -> cerrar")
        else:
            estado_actual = {'cara': 'thinking', 'frase': 'confianza_baja', 'timestamp': registro['timestamp']}
            if ser and ser.is_open:
                ser.write(b'0')

        return jsonify({
            'compostable': es_compostable,
            'confianza': round(confianza, 4),
            'raw': round(raw, 4)
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/estado_actual', methods=['GET'])
def get_estado_actual():
    return jsonify(estado_actual)

@app.route('/estadisticas', methods=['GET'])
def estadisticas():
    total = len(historial)
    if total == 0:
        return jsonify({
            'total': 0, 'compostables': 0, 'no_compostables': 0,
            'porcentaje': 0, 'ultimos': []
        })
    compostables = sum(1 for h in historial if h['compostable'])
    return jsonify({
        'total': total,
        'compostables': compostables,
        'no_compostables': total - compostables,
        'porcentaje': round((compostables / total) * 100, 1),
        'ultimos': historial[-10:][::-1]
    })

@app.route('/estado_arduino', methods=['GET'])
def estado_arduino():
    return jsonify({
        'conectado': ser is not None and ser.is_open,
        'puerto': PUERTO_ARDUINO
    })

# ========== INICIO ==========
if __name__ == '__main__':
    print("=" * 50)
    print("SERVIDOR COMPOSTAGE")
    print("=" * 50)
    print("Interfaz USUARIO:       http://localhost:5000/")
    print("Interfaz DESARROLLADOR: http://localhost:5000/admin")
    print("=" * 50)
    app.run(host='0.0.0.0', port=5000, debug=False)