/* ============================================= */
/* LÓGICA DE LA CARA DEL ROBOT                 */
/* ============================================= */

const robotFace = document.getElementById('robot-face');

function setFaceExpression(expression) {
    if (!robotFace) {
        console.error('No se encontró el elemento #robot-face');
        return;
    }

    robotFace.classList.remove('happy', 'sad', 'neutral');

    switch (expression) {
        case 'happy':
            robotFace.classList.add('happy');
            break;
        case 'sad':
            robotFace.classList.add('sad');
            break;
        case 'neutral':
        default:
            robotFace.classList.add('neutral');
            break;
    }

    console.log(`😐 Expresión facial cambiada a: ${expression}`);
}

document.addEventListener('DOMContentLoaded', () => {
    setFaceExpression('neutral');
});